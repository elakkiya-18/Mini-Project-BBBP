document.addEventListener("DOMContentLoaded", () => {
    const poster = document.querySelector("[data-achievement-poster]");
    if (!poster) return;

    const canvas = poster.querySelector("canvas");
    const context = canvas.getContext("2d");
    const status = poster.querySelector("[data-poster-status]");
    const playerName = poster.dataset.playerName || "Respect Quest player";
    const levels = Number(poster.dataset.levels || 0);
    const points = Number(poster.dataset.points || 0);
    const goldBadges = Number(poster.dataset.goldBadges || 0);
    const siteUrl = poster.dataset.siteUrl || "";

    function roundedRect(ctx, x, y, width, height, radius) {
        ctx.beginPath();
        ctx.roundRect(x, y, width, height, radius);
    }

    function drawPoster() {
        const { width, height } = canvas;
        const background = context.createLinearGradient(0, 0, width, height);
        background.addColorStop(0, "#432576");
        background.addColorStop(.52, "#793c9e");
        background.addColorStop(1, "#c13f82");
        context.fillStyle = background;
        context.fillRect(0, 0, width, height);

        context.globalAlpha = .12;
        context.fillStyle = "#fff";
        [[870, 90, 260], [105, 840, 220], [925, 1120, 310]].forEach(
            ([x, y, radius]) => {
                context.beginPath();
                context.arc(x, y, radius, 0, Math.PI * 2);
                context.fill();
            }
        );
        context.globalAlpha = 1;

        context.textAlign = "center";
        context.fillStyle = "#fce78f";
        context.font = "700 30px Arial, sans-serif";
        context.fillText("RESPECT QUEST", width / 2, 112);

        context.fillStyle = "#fff";
        context.font = "800 64px Arial, sans-serif";
        context.fillText("ACHIEVEMENT", width / 2, 218);
        context.font = "700 34px Arial, sans-serif";
        context.fillText("CELEBRATING LEARNING & EQUALITY", width / 2, 274);

        context.fillStyle = "#ffe08a";
        context.beginPath();
        context.arc(width / 2, 405, 76, 0, Math.PI * 2);
        context.fill();
        context.fillStyle = "#80501b";
        context.font = "700 84px Arial, sans-serif";
        context.fillText("★", width / 2, 435);

        context.fillStyle = "rgba(255,255,255,.14)";
        roundedRect(context, 78, 530, 924, 245, 28);
        context.fill();
        context.fillStyle = "#fff";
        context.font = "500 32px Arial, sans-serif";
        context.fillText("Proudly earned by", width / 2, 592);

        let nameFontSize = 68;
        context.font = `800 ${nameFontSize}px Arial, sans-serif`;
        while (context.measureText(playerName).width > 850 && nameFontSize > 40) {
            nameFontSize -= 2;
            context.font = `800 ${nameFontSize}px Arial, sans-serif`;
        }
        context.fillStyle = "#ffe08a";
        context.fillText(playerName, width / 2, 692);

        const statTop = 850;
        const statWidth = 278;
        const gap = 30;
        const startX = (width - (statWidth * 3 + gap * 2)) / 2;
        const stats = [
            { value: `${levels}/10`, label: "LEVELS COMPLETED" },
            { value: String(points), label: "POINTS EARNED" },
            { value: String(goldBadges), label: "GOLD BADGES" }
        ];

        stats.forEach((stat, index) => {
            const x = startX + index * (statWidth + gap);
            context.fillStyle = "rgba(255,255,255,.16)";
            roundedRect(context, x, statTop, statWidth, 190, 22);
            context.fill();
            context.fillStyle = "#fff";
            context.font = "800 56px Arial, sans-serif";
            context.fillText(stat.value, x + statWidth / 2, statTop + 83);
            context.fillStyle = "#f8eaff";
            context.font = "700 20px Arial, sans-serif";
            context.fillText(stat.label, x + statWidth / 2, statTop + 137);
        });

        context.fillStyle = "#fff";
        context.font = "600 29px Arial, sans-serif";
        context.fillText("Respect  •  Equality  •  Dignity", width / 2, 1190);
        context.fillStyle = "rgba(255,255,255,.82)";
        context.font = "24px Arial, sans-serif";
        context.fillText("Keep learning. Share respect.", width / 2, 1242);
        context.font = "20px Arial, sans-serif";
        context.fillText("Interactive quizzes about respect, equality, and dignity", width / 2, 1285);
        let urlFontSize = 21;
        context.font = `700 ${urlFontSize}px Arial, sans-serif`;
        while (context.measureText(siteUrl).width > width - 100 && urlFontSize > 14) {
            urlFontSize -= 1;
            context.font = `700 ${urlFontSize}px Arial, sans-serif`;
        }
        context.fillStyle = "#ffe08a";
        context.fillText(siteUrl, width / 2, 1325);
    }

    function setStatus(message) {
        status.textContent = message;
    }

    function getPosterBlob() {
        return new Promise((resolve, reject) => {
            canvas.toBlob(blob => {
                if (blob) resolve(blob);
                else reject(new Error("The poster image could not be created."));
            }, "image/png");
        });
    }

    poster.querySelector("[data-refresh-poster]").addEventListener("click", () => {
        drawPoster();
        setStatus("Poster refreshed with your current achievements.");
    });

    poster.querySelector("[data-copy-poster]").addEventListener("click", async () => {
        try {
            if (!navigator.clipboard?.write || !window.ClipboardItem) {
                throw new Error("Image clipboard access is not supported in this browser.");
            }
            const blob = await getPosterBlob();
            await navigator.clipboard.write([
                new ClipboardItem({ "image/png": blob })
            ]);
            setStatus("Poster image copied. Paste it into a post, message, or document.");
        } catch (error) {
            setStatus(`${error.message} Use Download poster to save and share the image.`);
        }
    });

    poster.querySelector("[data-download-poster]").addEventListener("click", async () => {
        try {
            const blob = await getPosterBlob();
            const downloadUrl = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = downloadUrl;
            link.download = "respect-quest-achievement.png";
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
            setStatus("Poster downloaded as a PNG image.");
        } catch (error) {
            setStatus(error.message);
        }
    });

    drawPoster();
});
