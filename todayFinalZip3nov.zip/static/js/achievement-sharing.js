document.addEventListener("DOMContentLoaded", () => {
    const feedback = document.querySelector("[data-share-feedback]");
    const status = document.querySelector("[data-share-status]");
    const fallbackLabel = feedback?.querySelector("label");
    const fallbackText = document.getElementById("shareFallbackText");

    document.querySelectorAll("[data-share-achievement]").forEach(button => {
        button.addEventListener("click", async () => {
            const title = button.dataset.shareTitle;
            const text = button.dataset.shareText;
            const shareData = { title, text };
            if (feedback) feedback.hidden = true;
            if (fallbackLabel) fallbackLabel.hidden = true;
            if (fallbackText) fallbackText.hidden = true;

            try {
                if (navigator.share) {
                    await navigator.share(shareData);
                    return;
                }

                if (!navigator.clipboard?.writeText) {
                    throw new Error("Clipboard access is unavailable in this browser.");
                }
                await navigator.clipboard.writeText(text);
                if (feedback) {
                    feedback.hidden = false;
                    if (status) {
                        status.textContent =
                            "Copied to your clipboard. Paste it into a post or message to share.";
                    }
                }
            } catch (error) {
                if (error.name === "AbortError") return;
                if (feedback && fallbackLabel && fallbackText) {
                    feedback.hidden = false;
                    if (status) {
                        status.textContent =
                            "Sharing and automatic copying are unavailable in this browser.";
                    }
                    fallbackLabel.hidden = false;
                    fallbackText.value = text;
                    fallbackText.hidden = false;
                    fallbackText.focus();
                    fallbackText.select();
                } else {
                    console.error("Could not share the Respect Quest achievement.", error);
                }
            }
        });
    });
});
