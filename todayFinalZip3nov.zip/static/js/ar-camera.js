window.initializeScenarioCamera = function ({
    toggleId,
    panelId,
    videoId,
    statusSelector,
    promptSelector,
    enabled = true
}) {
    const toggle = document.getElementById(toggleId);
    const panel = document.getElementById(panelId);
    const video = document.getElementById(videoId);
    const status = document.querySelector(statusSelector);
    const prompt = document.querySelector(promptSelector);
    if (!toggle || !panel || !video || !status || !prompt) return null;

    let stream = null;
    let isEnabled = enabled;
    let isStarting = false;
    let requestId = 0;

    function stop(invalidateRequest = true) {
        if (invalidateRequest) requestId += 1;
        isStarting = false;
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }
        video.srcObject = null;
        panel.hidden = true;
        toggle.textContent = "Start camera scenario view";
        toggle.setAttribute("aria-expanded", "false");
    }

    toggle.disabled = !isEnabled;
    toggle.addEventListener("click", async () => {
        if (stream) {
            stop();
            status.textContent = "Camera preview stopped.";
            return;
        }

        if (!navigator.mediaDevices?.getUserMedia) {
            status.textContent =
                "Camera access is unavailable. Use a supported browser over HTTPS or localhost.";
            return;
        }

        toggle.disabled = true;
        isStarting = true;
        const currentRequestId = ++requestId;
        status.textContent = "Requesting camera permission…";
        try {
            const requestedStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: { ideal: "environment" } },
                audio: false
            });
            if (currentRequestId !== requestId || !isEnabled) {
                requestedStream.getTracks().forEach(track => track.stop());
                return;
            }
            stream = requestedStream;
            video.srcObject = stream;
            await video.play();
            panel.hidden = false;
            toggle.textContent = "Stop camera scenario view";
            toggle.setAttribute("aria-expanded", "true");
            status.textContent =
                "Camera is on. The scenario appears over the live preview; video is not recorded or uploaded.";
        } catch (error) {
            if (currentRequestId !== requestId) return;
            stop(false);
            if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
                status.textContent =
                    "Camera permission was denied. Allow camera access in your browser settings to use this view.";
            } else if (error.name === "NotFoundError" || error.name === "DevicesNotFoundError") {
                status.textContent = "No camera was found. You can continue with the standard quiz.";
            } else {
                status.textContent =
                    `Could not start the camera: ${error.message || "unknown camera error"}.`;
            }
        } finally {
            if (currentRequestId === requestId) {
                isStarting = false;
                toggle.disabled = !isEnabled;
            }
        }
    });

    window.addEventListener("pagehide", stop);

    return {
        updatePrompt(value) {
            prompt.textContent = value;
        },
        setEnabled(value) {
            isEnabled = value;
            toggle.disabled = !isEnabled || isStarting;
            if (!isEnabled && (stream || isStarting)) {
                stop();
                status.textContent = "Camera preview stopped.";
            }
        },
        stop
    };
};
