document.addEventListener("DOMContentLoaded", () => {
    const roomElement = document.getElementById("multiplayerRoom");
    if (!roomElement) return;

    const code = roomElement.dataset.roomCode;
    let currentUserId = Number(roomElement.dataset.currentUserId);
    const statusElement = document.getElementById("matchStatus");
    const playersElement = document.getElementById("multiplayerPlayers");
    const startButton = document.getElementById("startMatch");
    const startHint = document.getElementById("startMatchHint");
    const hostMessage = document.getElementById("lobbyHostMessage");
    const progressElement = document.getElementById("questionProgress");
    const timerElement = document.getElementById("questionTimer");
    const promptElement = document.getElementById("questionPrompt");
    const optionsElement = document.getElementById("answerOptions");
    const feedbackElement = document.getElementById("answerFeedback");
    const errorElement = document.getElementById("matchError");
    const podiumElement = document.getElementById("multiplayerPodium");
    const podiumPlacements = document.getElementById("podiumPlacements");
    const arCamera = window.initializeScenarioCamera?.({
        toggleId: "multiplayerArCameraToggle",
        panelId: "multiplayerArCameraPanel",
        videoId: "multiplayerArCameraVideo",
        statusSelector: "[data-multiplayer-ar-status]",
        promptSelector: "[data-multiplayer-ar-question]",
        enabled: false
    });
    const placementGifs = [
        "https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExbW54M3F6aG5ucjVoN3ZjY2RjNDZzeWMzN2x2OTc1YTZlZjN4bWU1cSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/7nTOoY8rKV5Ew6kFo2/giphy.gif",
        "https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExY2VmbTBoc2ZtaXUzYXdibjNpZnEzbnE3MWl5ZmtsdGxudzAyMWI2cCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/g376WXJ1S5R3oyVCMb/giphy.gif",
        "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExZzEzdjBsbzVhNGZqbnF0azh1eTBoZTY2eGV1bTZodG1ydTZieHAydyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/TtBSnfcjKkJ9NgzFub/giphy.gif",
    ];
    let podiumRendered = false;
    let polling = false;

    async function postJSON(path, body = {}) {
        const response = await fetch(path, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(body)
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "The request failed.");
        return result;
    }

    function showError(message) {
        errorElement.textContent = message;
        errorElement.classList.remove("d-none");
    }

    function renderPlayers(players) {
        playersElement.replaceChildren();
        players.forEach((player, index) => {
            const item = document.createElement("li");
            item.className = "player-list-item";
            const playerInfo = document.createElement("div");
            playerInfo.className = "player-info";
            const rank = document.createElement("span");
            rank.className = `player-rank rank-${Math.min(index + 1, 3)}`;
            rank.textContent = String(index + 1);
            rank.setAttribute("aria-label", `Rank ${index + 1}`);
            const identity = document.createElement("span");
            identity.className = "player-name";
            identity.textContent = player.username + (
                player.user_id === currentUserId ? " (you)" : ""
            );
            if (player.is_host) {
                const hostBadge = document.createElement("span");
                hostBadge.className = "host-badge";
                hostBadge.textContent = "Host";
                identity.append(" ", hostBadge);
            }
            playerInfo.append(rank, identity);
            const score = document.createElement("strong");
            score.textContent = `${player.score} pts`;
            item.append(playerInfo, score);
            if (index === 0 && player.score > 0) {
                item.classList.add("is-leading");
            }
            playersElement.append(item);
        });
    }

    function renderPodium(players) {
        if (podiumRendered || !podiumElement || !podiumPlacements) return;
        podiumPlacements.replaceChildren();
        players.slice(0, 3).forEach((player, index) => {
            const placement = document.createElement("article");
            placement.className = `podium-card podium-place-${index + 1}`;
            const image = document.createElement("img");
            image.src = placementGifs[index];
            image.alt = `${index + 1}${index === 0 ? "st" : index === 1 ? "nd" : "rd"} place celebration`;
            image.loading = "lazy";
            const title = document.createElement("h3");
            title.className = "h5 mb-1";
            title.textContent = `${index + 1}${index === 0 ? "st" : index === 1 ? "nd" : "rd"} place`;
            const name = document.createElement("p");
            name.className = "mb-1";
            name.textContent = player.username + (
                player.user_id === currentUserId ? " (you)" : ""
            );
            const score = document.createElement("strong");
            score.textContent = `${player.score} / 100 points`;
            placement.append(image, title, name, score);
            podiumPlacements.append(placement);
        });
        podiumElement.classList.remove("d-none");
        podiumRendered = true;
    }

    function renderQuestion(state) {
        const {room, question, own_answer: ownAnswer, reveal} = state;
        statusElement.textContent = room.status === "waiting"
            ? "Waiting for players"
            : room.status === "completed" ? "Match complete" : "Match in progress";
        const hostPlayer = state.players.find(player => player.is_host);
        const isCurrentHost = room.is_host;
        if (hostMessage) {
            if (room.status === "waiting" && !isCurrentHost) {
                hostMessage.textContent =
                    `Waiting for ${hostPlayer?.username || "the host"} to start the match.`;
            } else {
                hostMessage.textContent = isCurrentHost
                    ? "You are the host."
                    : `Host: ${hostPlayer?.username || "unknown"}.`;
            }
        }

        if (room.status === "waiting") {
            arCamera?.setEnabled(false);
            progressElement.textContent = "Waiting";
            timerElement.textContent = "—";
            promptElement.textContent = "Share the room code and wait for the host.";
            optionsElement.replaceChildren();
            feedbackElement.textContent = "";
            if (startButton) {
                startButton.hidden = !isCurrentHost;
                startButton.classList.toggle("d-none", !isCurrentHost);
                startButton.disabled = !isCurrentHost || state.players.length < 2;
            }
            if (startHint) {
                startHint.hidden = !isCurrentHost;
                startHint.classList.toggle("d-none", !isCurrentHost);
                startHint.textContent = state.players.length < 2
                    ? "Start when at least 2 players have joined."
                    : "All set—start the match when everyone is ready.";
            }
            return;
        }

        startButton?.classList.add("d-none");
        if (startButton) startButton.hidden = true;
        startHint?.classList.add("d-none");
        if (startHint) startHint.hidden = true;
        if (room.status === "completed") {
            arCamera?.setEnabled(false);
            progressElement.textContent = "Finished";
            timerElement.textContent = "✓";
            promptElement.textContent = "Challenge complete! See the final standings below.";
            optionsElement.replaceChildren();
            feedbackElement.textContent = "Great game!";
            renderPodium(state.players);
            return;
        }

        progressElement.textContent = `Question ${question.number} / ${room.question_count}`;
        arCamera?.setEnabled(true);
        timerElement.textContent = `${room.time_remaining}s`;
        timerElement.classList.toggle("is-urgent", room.time_remaining <= 5);
        promptElement.textContent = question.prompt;
        arCamera?.updatePrompt(question.prompt);
        optionsElement.replaceChildren();

        question.options.forEach(option => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "multiplayer-option";
            button.textContent = `${option.key}. ${option.text}`;
            button.disabled = Boolean(ownAnswer);
            if (ownAnswer?.selected_answer === option.key) {
                button.classList.add("is-selected");
            }
            button.addEventListener("click", async () => {
                optionsElement.querySelectorAll("button").forEach(item => {
                    item.disabled = true;
                });
                try {
                    await postJSON(`/multiplayer/${code}/answer`, {answer: option.key});
                    await refreshState();
                } catch (error) {
                    showError(error.message);
                    await refreshState();
                }
            });
            optionsElement.append(button);
        });

        if (ownAnswer) {
            feedbackElement.textContent = ownAnswer.is_correct
                ? `Correct! +${ownAnswer.points} points.`
                : "Not quite. Wait for the next question.";
            feedbackElement.className = `mb-0 mt-3 ${ownAnswer.is_correct ? "text-success" : "text-muted"}`;
        } else if (reveal) {
            feedbackElement.textContent = `Previous answer: ${reveal.is_correct ? "correct" : `the correct answer was ${reveal.correct_answer}`}.`;
            feedbackElement.className = "mb-0 mt-3 text-primary";
        } else {
            const answered = state.players.filter(player => player.answered).length;
            feedbackElement.textContent = `${answered} of ${state.players.length} players answered.`;
            feedbackElement.className = "mb-0 mt-3 text-muted";
        }
    }

    async function refreshState() {
        if (polling) return;
        polling = true;
        try {
            const state = await postJSON(`/multiplayer/${code}/state`);
            errorElement.classList.add("d-none");
            currentUserId = state.current_user_id;
            renderPlayers(state.players);
            renderQuestion(state);
        } catch (error) {
            showError(error.message);
        } finally {
            polling = false;
        }
    }

    startButton?.addEventListener("click", async () => {
        startButton.disabled = true;
        try {
            await postJSON(`/multiplayer/${code}/start`);
            await refreshState();
        } catch (error) {
            await refreshState();
            showError(error.message);
        }
    });

    refreshState();
    window.setInterval(refreshState, 1000);
});
